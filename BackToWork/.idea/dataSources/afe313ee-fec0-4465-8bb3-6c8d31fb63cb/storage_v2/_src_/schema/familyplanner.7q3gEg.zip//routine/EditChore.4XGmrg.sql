create
    definer = erward@`%` procedure EditChore(IN P_ChoreID varchar(45), IN P_Name varchar(45),
                                             IN P_Description varchar(45))
BEGIN
	UPDATE chore
    SET
		choreName = P_Name,
        choreDescription = P_Description
	WHERE
		choreID = P_ChoreID;
END;

