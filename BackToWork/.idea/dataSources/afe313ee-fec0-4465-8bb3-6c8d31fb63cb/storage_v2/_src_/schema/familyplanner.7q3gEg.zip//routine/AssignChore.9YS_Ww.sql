create
    definer = erward@`%` procedure AssignChore(IN P_ChoreID int, IN P_UserID int, IN P_FamilyID int)
BEGIN
	INSERT INTO assigned_chore(userID, choreID, familyID, status) VALUES(P_UserID, P_ChoreID, P_FamilyID, "INCOMPLETE");
END;

