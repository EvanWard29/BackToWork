create
    definer = erward@`%` procedure AddChore(IN P_choreName varchar(45), IN P_choreDescription varchar(45))
BEGIN
	INSERT INTO chore(choreName, choreDescription) VALUES(P_choreName, P_choreDescription);
END;

