create
    definer = admin@`%` procedure UpdateUser(IN P_UserID int, IN P_FirstName varchar(45), IN P_ChoresCompleted int,
                                             IN P_Points int)
BEGIN
	UPDATE user
    SET
    firstName = P_FirstName,
    choresCompleted = P_ChoresCompleted,
    points = P_Points
    WHERE
    userID = P_UserID;
END;

