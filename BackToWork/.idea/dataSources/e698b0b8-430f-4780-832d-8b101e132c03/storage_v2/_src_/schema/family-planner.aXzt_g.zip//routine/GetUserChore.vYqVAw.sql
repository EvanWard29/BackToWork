create
    definer = admin@`%` procedure GetUserChore(IN P_FamilyID int, IN P_AssignedChoreID int)
BEGIN
	SELECT userID INTO @UserID FROM assigned_chore WHERE familyID = P_FamilyID AND userChoreID = P_AssignedChoreID;
    SELECT firstName FROM user WHERE userID = @UserID;
END;

