create
    definer = admin@`%` procedure AddEvent(IN P_EventName varchar(45), IN P_EventDescription varchar(100),
                                           IN P_EventType varchar(45), IN P_EventDate datetime, IN P_FamilyID int)
BEGIN
	INSERT INTO event(eventName, eventDescription, eventType, eventDate, familyID) 
    VALUES(P_EventName, P_EventDescription, P_EventType, P_EventDate, P_FamilyID);
END;

