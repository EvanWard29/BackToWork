create
    definer = admin@`%` procedure ApproveRequest(IN P_RequestID int)
BEGIN
	SELECT userID INTO @UserID FROM reward_request WHERE requestID = P_RequestID;
    SELECT points INTO @UserPoints FROM user WHERE userID = @UserID;
    
    SELECT rewardID INTO @RewardID FROM reward_request WHERE requestID = P_RequestID;
    SELECT rewardPoints INTO @RewardPoints FROM rewards WHERE rewardID = @RewardID;
    
    SET @NewPoints = @UserPoints - @RewardPoints;
    UPDATE user SET points = @NewPoints WHERE userID = @UserID;
    
    UPDATE reward_request SET requestStatus = 'APPROVED' WHERE requestID = P_RequestID;
END;

