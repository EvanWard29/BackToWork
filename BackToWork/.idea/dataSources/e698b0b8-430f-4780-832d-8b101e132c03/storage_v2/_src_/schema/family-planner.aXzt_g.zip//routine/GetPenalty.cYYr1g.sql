create
    definer = admin@`%` procedure GetPenalty(IN P_AssignedChoreID int)
BEGIN
	SELECT choreID INTO @ChoreID FROM assigned_chore WHERE userChoreID = P_AssignedChoreID;
    SELECT penalty FROM chore WHERE choreID = @ChoreID;
END;

