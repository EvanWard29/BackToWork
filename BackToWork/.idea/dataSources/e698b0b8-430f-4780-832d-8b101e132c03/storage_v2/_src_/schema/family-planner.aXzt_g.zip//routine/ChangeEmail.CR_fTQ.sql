create
    definer = admin@`%` procedure ChangeEmail(IN P_CurrentEmail varchar(45), IN P_NewEmail varchar(45))
BEGIN
	UPDATE user SET email = P_NewEmail WHERE email = P_CurrentEmail;
END;

