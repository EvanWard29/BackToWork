create
    definer = admin@`%` procedure RequestReward(IN P_RewardID int, IN P_FamilyID int, IN P_UserID int)
BEGIN
	SELECT CURDATE() INTO @currentDate;
	INSERT INTO reward_request(rewardID, familyID, userID, requestStatus, date) VALUES(P_RewardID, P_FamilyID, P_UserID, "PROCESSING", @CurrentDate);
END;

