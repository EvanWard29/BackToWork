create
    definer = admin@`%` procedure CompleteChore(IN P_UserChoreID int, IN P_FamilyID int)
BEGIN
	SELECT userID, choreID INTO @UserID, @ChoreID FROM assigned_chore WHERE userChoreID = P_UserChoreID AND familyID = P_FamilyID;
	SELECT points INTO @Points FROM chore WHERE choreID = @ChoreID;
    
    UPDATE user SET choresCompleted = choresCompleted + 1, points = points + @Points WHERE userID = @UserID;
    DELETE FROM event WHERE assignedChoreID = P_UserChoreID AND familyID = P_FamilyID;
    DELETE FROM assigned_chore WHERE userChoreID = P_UserChoreID AND familyID = P_FamilyID;
END;

