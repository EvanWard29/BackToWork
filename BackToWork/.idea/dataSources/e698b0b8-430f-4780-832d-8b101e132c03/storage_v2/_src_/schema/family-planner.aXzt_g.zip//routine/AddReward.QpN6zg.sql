create
    definer = admin@`%` procedure AddReward(IN P_RewardName varchar(45), IN P_PointsCost int, IN P_FamilyID int)
BEGIN
	INSERT INTO rewards(rewardName, rewardPoints, familyID) VALUES(P_RewardName, P_PointsCost, P_FamilyID);
END;

