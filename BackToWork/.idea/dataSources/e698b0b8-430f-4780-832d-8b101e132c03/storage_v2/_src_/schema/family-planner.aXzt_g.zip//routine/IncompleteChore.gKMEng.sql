create
    definer = admin@`%` procedure IncompleteChore(IN P_UserChoreID int, IN P_FamilyID int)
BEGIN
	SELECT userID INTO @UserID FROM assigned_chore WHERE userChoreID = P_UserChoreID AND familyID = P_FamilyID;
    
    UPDATE user SET choresCompleted = choresCompleted + 1 WHERE userID = @UserID;
    DELETE FROM event WHERE assignedChoreID = P_UserChoreID AND familyID = P_FamilyID;
    DELETE FROM assigned_chore WHERE userChoreID = P_UserChoreID AND familyID = P_FamilyID;
END;

