create
    definer = admin@`%` procedure GetUserPoints(IN P_AssignedChoreID int)
BEGIN
	SELECT familyID, userID INTO @FamilyID, @UserID FROM assigned_chore WHERE userChoreID = P_AssignedChoreID;
    SELECT points FROM user WHERE userID = @UserID AND familyID = @FamilyID;
END;

