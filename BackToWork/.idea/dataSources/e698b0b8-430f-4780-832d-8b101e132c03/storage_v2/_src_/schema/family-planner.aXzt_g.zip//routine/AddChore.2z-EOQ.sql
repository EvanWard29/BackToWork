create
    definer = admin@`%` procedure AddChore(IN P_choreName varchar(45), IN P_choreDescription varchar(150),
                                           IN P_Points int, IN P_Penalty int, IN P_FamilyID int)
BEGIN
	INSERT INTO chore(choreName, choreDescription, points, penalty, familyID) VALUES(P_choreName, P_choreDescription, P_Points, P_Penalty, P_FamilyID);
END;

