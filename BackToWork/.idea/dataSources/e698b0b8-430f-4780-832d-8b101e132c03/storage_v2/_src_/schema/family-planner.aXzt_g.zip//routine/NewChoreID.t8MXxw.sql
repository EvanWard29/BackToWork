create
    definer = admin@`%` procedure NewChoreID()
BEGIN
	SELECT `AUTO_INCREMENT`
	FROM  INFORMATION_SCHEMA.TABLES
	WHERE TABLE_SCHEMA = 'familyplanner'
	AND   TABLE_NAME   = 'chore';
END;

