create
    definer = admin@`%` procedure UpdatePoints(IN P_AssignedChoreID int, IN P_Points int)
BEGIN
	SELECT userID INTO @UserID FROM assigned_chore WHERE userChoreID = P_AssignedChoreID;
    UPDATE user SET points = P_Points WHERE userID = @UserID;
END;

