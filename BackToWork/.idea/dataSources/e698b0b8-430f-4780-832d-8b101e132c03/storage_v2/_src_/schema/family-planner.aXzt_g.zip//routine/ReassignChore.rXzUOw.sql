create
    definer = admin@`%` procedure ReassignChore(IN P_UserChoreID int, IN P_User varchar(45), IN P_FamilyID int)
BEGIN
	SELECT userID INTO @UserID FROM user WHERE firstName = P_User;
    UPDATE assigned_chore SET userID = @UserID WHERE userChoreID = P_UserChoreID;
END;

