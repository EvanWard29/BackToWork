create
    definer = admin@`%` procedure ChangePassword(IN P_Email varchar(45), IN P_Password varchar(45))
BEGIN
	UPDATE user SET password = P_Password WHERE email = P_Email;
END;

