create
    definer = admin@`%` procedure AssignChore(IN P_ChoreID int, IN P_Username varchar(45), IN P_FamilyID int,
                                              IN P_Deadline datetime)
BEGIN
	SELECT userID INTO @userID FROM user WHERE firstName = P_Username AND familyID = P_FamilyID;
	INSERT INTO assigned_chore(userID, choreID, familyID, deadline, status) VALUES(@userID, P_ChoreID, P_FamilyID, P_Deadline, "INCOMPLETE");
    
    SELECT choreName, choreDescription INTO @ChoreName, @ChoreDescription FROM chore WHERE choreID = P_ChoreID;
    
    SELECT userChoreID INTO @AssignedChoreID FROM assigned_chore ORDER BY userChoreID DESC LIMIT 1;
    
    INSERT INTO event(eventName, eventDescription, eventType, eventDate, familyID, assignedChoreID) 
		VALUES(@ChoreName, @ChoreDescription, 'CHORE', P_Deadline, P_FamilyID, @AssignedChoreID);
END;

