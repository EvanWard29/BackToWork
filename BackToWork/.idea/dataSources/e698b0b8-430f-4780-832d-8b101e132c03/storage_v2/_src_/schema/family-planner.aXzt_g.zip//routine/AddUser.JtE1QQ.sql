create
    definer = admin@`%` procedure AddUser(IN P_FirstName varchar(45), IN P_LastName varchar(45), IN P_Type int,
                                          IN P_Email varchar(45), IN P_Password varchar(150), IN P_Points int,
                                          IN P_ChoresCompleted int, IN P_FamilyID int)
BEGIN
	IF P_FamilyID = 0 THEN
		INSERT INTO family(familyName, numMembers)
			VALUES(P_LastName, 0);
		SELECT LAST_INSERT_ID() INTO P_FamilyID;
	END IF;
    
	INSERT INTO user(firstName, lastName, type, email, password, points, choresCompleted, familyID) 
		VALUES(P_FirstName, P_LastName, P_Type, P_Email, P_Password, P_Points, P_ChoresCompleted, P_FamilyID);
	UPDATE family SET numMembers = numMembers + 1 WHERE familyID = P_FamilyID;
END;

