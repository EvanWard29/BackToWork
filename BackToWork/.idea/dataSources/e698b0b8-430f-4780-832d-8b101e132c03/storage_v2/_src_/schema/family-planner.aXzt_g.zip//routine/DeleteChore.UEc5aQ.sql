create
    definer = admin@`%` procedure DeleteChore(IN P_ChoreID int)
BEGIN
	DELETE FROM chore WHERE choreID = P_ChoreID;
END;

