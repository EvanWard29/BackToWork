create
    definer = admin@`%` procedure EditChore(IN P_ChoreID varchar(45), IN P_Name varchar(45),
                                            IN P_Description varchar(150), IN P_Points int)
BEGIN
	UPDATE chore
    SET
		choreName = P_Name,
        choreDescription = P_Description,
        points = P_Points
	WHERE
		choreID = P_ChoreID;
END;

